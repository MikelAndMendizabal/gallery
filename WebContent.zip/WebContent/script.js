
$(document).ready(function() {

	$('#block0').show();
	$('#block1').hide();
	$('#block2').hide();
	$('#block3').hide();
	$('#block4').hide();
	$('#block5').hide();
	$('#block6').hide();
	$('#block7').hide();
	$('#block8').hide();

	$('.main-logo').mouseenter(function() {
		$(this).animate( {
			width : '+=10px'
		});

	});

	$('.main-logo').mouseleave(function() {
		$(this).animate( {
			width : '-=10px'
		});

	});

	$(function() {
		$('.main-logo').click(function() {
			$(this).toggle(1000);

			switch ($(this).attr("id")) {
			case "main-top-left":
				$('#block1').show();
				$('#block0').hide();
				$('#block2').hide();
				$('#block3').hide();
				$('#block4').hide();
				$('#block5').hide();
				$('#block6').hide();
				$('#block7').hide();
				$('#block8').hide();

				break;

			case "main-top-center":
				$('#block2').show();
				$('#block0').hide();
				$('#block1').hide();
				$('#block3').hide();
				$('#block4').hide();
				$('#block5').hide();
				$('#block6').hide();
				$('#block7').hide();
				$('#block8').hide();
				break;

			case "main-top-right":
				$('#block3').show();
				$('#block0').hide();
				$('#block1').hide();
				$('#block2').hide();
				$('#block4').hide();
				$('#block5').hide();
				$('#block6').hide();
				$('#block7').hide();
				$('#block8').hide();
				break;

			case "main-middle-left":
				$('#block4').show();
				$('#block0').hide();
				$('#block1').hide();
				$('#block2').hide();
				$('#block3').hide();
				$('#block5').hide();
				$('#block6').hide();
				$('#block7').hide();
				$('#block8').hide();
				break;

			case "main-middle-center":
				$('#block5').show();
				$('#block0').hide();
				$('#block1').hide();
				$('#block2').hide();
				$('#block3').hide();
				$('#block4').hide();
				$('#block6').hide();
				$('#block7').hide();
				$('#block8').hide();
				break;

			case "main-middle-right":
				$('#block6').show();
				$('#block0').hide();
				$('#block1').hide();
				$('#block2').hide();
				$('#block3').hide();
				$('#block4').hide();
				$('#block5').hide();
				$('#block7').hide();
				$('#block8').hide();
				break;

			case "main-low-left":
				$('#block7').show();
				$('#block0').hide();
				$('#block1').hide();
				$('#block2').hide();
				$('#block3').hide();
				$('#block4').hide();
				$('#block5').hide();
				$('#block6').hide();
				$('#block8').hide();
				break;

			case "main-low-right":
				$('#block8').show();
				$('#block0').hide();
				$('#block1').hide();
				$('#block2').hide();
				$('#block3').hide();
				$('#block4').hide();
				$('#block5').hide();
				$('#block6').hide();
				$('#block7').hide();
				break;

			}

		});
	});

	
});
